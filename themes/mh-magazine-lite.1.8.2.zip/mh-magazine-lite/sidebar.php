<aside class="mh-sidebar <?php mh_sb_class(); ?>">
	<?php dynamic_sidebar('sidebar'); ?>
</aside>