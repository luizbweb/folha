<div id="message" class="updated jetpack-message jp-connect" style="display:block !important;">
		<div class="jetpack-wrap-container">
			<div class="jetpack-text-container">
				<h4>
					<p><?php echo $data['notice']; ?></p>
				</h4>
			</div>
		</div>
</div>
