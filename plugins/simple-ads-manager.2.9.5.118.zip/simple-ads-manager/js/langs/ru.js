tinyMCE.addI18n("ru,samb", {
	'Insert Advertisement' : 'Вставить рекламное объявление',
  'Select Advertisement Object': 'Выбрать объект рекламы',
  'Insert Single Ad': 'Вставить объявление',
  'Insert Ads Place': 'Вставить рекламное место',
  'Insert Ads Zone': 'Вставить рекламную зону',
  'Insert Ads Block': 'Вставить блок рекламы'
});